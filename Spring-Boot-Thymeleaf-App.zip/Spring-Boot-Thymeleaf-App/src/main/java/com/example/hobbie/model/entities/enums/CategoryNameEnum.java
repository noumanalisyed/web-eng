package com.example.hobbie.model.entities.enums;

public enum CategoryNameEnum {
    ACTIVE, FUN, CREATIVE, RELAX, INTELLECTUAL, SOCIAL, OTHER;
}
