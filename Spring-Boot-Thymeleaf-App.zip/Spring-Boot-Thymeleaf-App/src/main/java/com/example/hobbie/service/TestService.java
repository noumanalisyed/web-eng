package com.example.hobbie.service;

import com.example.hobbie.model.entities.Test;
import com.example.hobbie.model.service.TestServiceModel;

public interface TestService {
    void saveTest(TestServiceModel map);
}
