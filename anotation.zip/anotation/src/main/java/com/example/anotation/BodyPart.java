package com.example.anotation;

public interface BodyPart {
    void display();
}
