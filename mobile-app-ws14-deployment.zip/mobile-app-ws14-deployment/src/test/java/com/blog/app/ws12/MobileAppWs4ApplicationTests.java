package com.blog.app.ws12;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobileAppWs4ApplicationTests {

    @Test
    void contextLoads() {
    }

}
