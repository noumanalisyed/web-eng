package com.blog.app.ws12.ui.controller;

public enum RequestOperationName {
	DELETE,
	VERIFY_EMAIL,
	REQUEST_PASSWORD_RESET,
	PASSWORD_RESET
}
