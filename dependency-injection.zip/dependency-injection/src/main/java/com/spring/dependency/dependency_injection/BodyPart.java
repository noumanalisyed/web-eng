package com.spring.dependency.dependency_injection;

public interface BodyPart {
    void display();
}
