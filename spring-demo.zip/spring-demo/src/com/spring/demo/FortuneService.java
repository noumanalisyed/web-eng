package com.spring.demo;

public interface FortuneService {
    public String getFortune();
}
