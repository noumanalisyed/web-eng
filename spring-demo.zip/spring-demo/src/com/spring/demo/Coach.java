package com.spring.demo;

public interface Coach {
	public String getDailyWorkout();	
	public String getDailyFortune();
	public String getInformation();
}
